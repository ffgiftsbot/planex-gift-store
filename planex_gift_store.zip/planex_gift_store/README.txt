PLANEX GIFT STORE — starter website

HOW TO USE ON ANDROID (ACODE)
1. Extract planex_gift_store.zip.
2. Open the extracted folder in Acode.
3. Open index.html and preview it in a browser.

FILES
- index.html: page structure
- style.css: responsive dark/orange design
- script.js: sample catalog, search, filters, cart and wishlist

IMPORTANT
This is a front-end demo/starter, not a live top-up service.
UID lookup is a demo validation only. Orders are not sent to a server.
Prices, stock and gift names are sample data. Before accepting real orders:
- use an authorized Free Fire item supplier/API,
- build a secure backend and admin authentication,
- verify order status server-side,
- use a legitimate payment provider and never store payment PIN/OTP.
